define( function ( require ) {

	"use strict";

	return {
		app_slug : 'coke-beats',
		wp_ws_url : 'http://104.238.96.209/~project/newsletter/wp-appkit-api/coke-beats',
		wp_url : 'http://104.238.96.209/~project/newsletter',
		theme : 'coke-bootstrap',
		//theme : 'framework7-ios',
		//theme : 'off-canvas-ios2',
        //theme : 'q-ios2',
        version : '1.0',
		app_title : 'Coke Beats',
		app_platform : 'ios',
		gmt_offset : 0,
		debug_mode : 'off',
		auth_key : '8G+akaibrYn; awTKI,=dQPM:_Hsjm3wip@44-X=$h|hA33>CH[ZD Cj_|?)vfAQ',
		options : {"refresh_interval":30},
		theme_settings : [],
		addons : []
	};

});
