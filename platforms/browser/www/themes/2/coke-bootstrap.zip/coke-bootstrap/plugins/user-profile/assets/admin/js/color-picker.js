	jQuery(document).ready(function(jQuery)
		{	


			//jQuery('#up-paratheme_items_position_color, #up-paratheme_items_content_color, #up-paratheme_items_title_color ').wpColorPicker();
					
					


		});